/* ====================================================================
 *  SHARED LIB  (di-inject otomatis ke setiap providers/*.js oleh build.js)
 *  Aturan Nuvio: Hermes engine, pakai fetch + Promise (.then), tanpa npm.
 * ==================================================================== */
var UA = 'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36';

// >>> ISI DI SINI: API key TMDB gratis (https://www.themoviedb.org/settings/api)
// Fallback untuk Nuvio versi yang belum mendukung pengaturan plugin.
// Lebih aman masukkan key lewat Settings provider jika tersedia.
// Boleh v3 API key (32 karakter) atau v4 API Read Access Token (diawali eyJ).
var TMDB_API_KEY = '';

// Jangan memakai setTimeout di runtime plugin: beberapa build Nuvio tidak menyediakannya.
// Nuvio sendiri membatasi waktu eksekusi provider.

function log(tag, msg) { try { console.log('[' + tag + '] ' + msg); } catch (e) {} }
function flatten(arr) { var o = []; for (var i = 0; i < arr.length; i++) for (var j = 0; j < arr[i].length; j++) o.push(arr[i][j]); return o; }
function uniq(arr) { var s = {}, o = []; for (var i = 0; i < arr.length; i++) { if (arr[i] && !s[arr[i]]) { s[arr[i]] = 1; o.push(arr[i]); } } return o; }

/* ---------- HTTP ---------- */
function request(url, opts) {
  opts = opts || {};
  var headers = Object.assign({ 'User-Agent': UA, 'Accept-Language': 'en-US,en;q=0.9' }, opts.headers || {});
  return fetch(url, { method: opts.method || 'GET', headers: headers, body: opts.body, redirect: 'follow' })
    .then(function (r) {
      if (r.status >= 400) throw new Error('HTTP ' + r.status + ' ' + url);
      return r.text();
    });
}
function requestJson(url, opts) { return request(url, opts).then(function (t) { return JSON.parse(t); }); }

/* ---------- string utils ---------- */
function decodeHtml(s) {
  return String(s || '').replace(/&amp;/g, '&').replace(/&#0?39;|&#8217;|&rsquo;/g, "'").replace(/&quot;|&#8220;|&#8221;/g, '"').replace(/&#8211;|&ndash;/g, '-').replace(/&nbsp;/g, ' ');
}
function stripTags(s) { return decodeHtml(String(s || '').replace(/<[^>]+>/g, ' ')).replace(/\s+/g, ' ').trim(); }
function norm(s) { return decodeHtml(s).toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim(); }
function stripEp(s) { return String(s || '').replace(/\b(?:episode|ep|eps)\.?\s*\d+.*$/i, '').replace(/\s*[-:]\s*\d+\s*$/, ''); }
var STOP = { the: 1, a: 1, an: 1, of: 1, and: 1, hd: 1, uncensored: 1, ova: 1, ona: 1, subbed: 1, sub: 1, dub: 1, dubbed: 1, english: 1, hentai: 1 };
function tokens(s) { return norm(stripEp(s)).split(' ').filter(function (t) { return t && !STOP[t]; }); }
function similarity(a, b) {
  var ta = tokens(a), tb = tokens(b);
  if (!ta.length || !tb.length) return 0;
  var A = ta.join(' '), B = tb.join(' ');
  if (A === B) return 1;
  var inter = 0, i;
  for (i = 0; i < ta.length; i++) if (tb.indexOf(ta[i]) >= 0) inter++;
  var jac = inter / (ta.length + tb.length - inter);
  if (A.indexOf(B) >= 0 || B.indexOf(A) >= 0) jac = Math.max(jac, 0.85);
  return jac;
}
// cands: [{title,url}] ; titles: [string] -> kandidat terbaik (skor >= min)
function bestMatch(cands, titles, min) {
  var best = null, bs = 0;
  for (var i = 0; i < cands.length; i++) {
    for (var j = 0; j < titles.length; j++) {
      var sc = similarity(cands[i].title, titles[j]);
      if (sc > bs) { bs = sc; best = cands[i]; }
    }
  }
  return bs >= (min || 0.6) ? best : null;
}
function attr(tag, name) {
  var m = new RegExp('\\b' + name + '\\s*=\\s*["\']([^"\']*)["\']', 'i').exec(tag);
  return m ? decodeHtml(m[1]) : '';
}
function originOf(u) { var m = /^(https?:\/\/[^\/?#]+)/i.exec(u || ''); return m ? m[1] : ''; }
function abs(u, base) {
  u = decodeHtml(u || '').trim();
  if (!u) return '';
  if (/^https?:\/\//i.test(u)) return u;
  if (u.indexOf('//') === 0) return 'https:' + u;
  if (u.charAt(0) === '/') return originOf(base) + u;
  return base.replace(/[^\/]*$/, '') + u;
}
function epNumber(s) {
  var m = /(?:episode|ep|eps)[\s._-]*0*(\d+)/i.exec(s || '') || /-0*(\d+)\/?(?:[?#].*)?$/.exec(s || '');
  return m ? parseInt(m[1], 10) : null;
}

/* ---------- parsing ---------- */
// Ambil semua <a href> yang cocok pathRe -> [{url,title}]
function parseLinks(html, base, pathRe) {
  var re = /<a\b([^>]*)>([\s\S]*?)<\/a>/gi, m, map = {}, order = [];
  while ((m = re.exec(html))) {
    var href = abs(attr(m[1], 'href'), base);
    if (!href || !pathRe.test(href)) continue;
    href = href.replace(/#.*$/, '');
    var imgAlt = /<img[^>]*\balt=["']([^"']+)["']/i.exec(m[2]);
    var title = attr(m[1], 'title') || stripTags(m[2]) || (imgAlt ? decodeHtml(imgAlt[1]) : '');
    if (!map[href]) { map[href] = ''; order.push(href); }
    if (title.length > map[href].length) map[href] = title;
  }
  return order.map(function (u) { return { url: u, title: map[u] }; }).filter(function (c) { return c.title; });
}

var BAD_URL = /\.(jpe?g|png|gif|webp|svg|css|js|ico|woff2?|vtt|srt)(\?|$)|wp-json|wp-content|gravatar|google|facebook|twitter|schema\.org|w\.org|sample|big_?buck|test-streams/i;
function extractLinks(text) {
  var s = String(text).replace(/\\\//g, '/').replace(/&amp;/g, '&'), re = /https?:\/\/[^"'\s<>\\)]+/g, m, out = [];
  while ((m = re.exec(s))) if (!BAD_URL.test(m[0])) out.push(m[0]);
  return uniq(out);
}

// p.a.c.k.e.d unpacker (banyak embed player pakai ini)
function unpack(src) {
  if (src.indexOf('eval(function(p,a,c,k,e') < 0) return null;
  var m = /\}\('((?:[^'\\]|\\.)*)',\s*(\d+),\s*(\d+),\s*'((?:[^'\\]|\\.)*)'\.split\('\|'\)/.exec(src);
  if (!m) return null;
  var p = m[1], a = parseInt(m[2], 10), c = parseInt(m[3], 10), k = m[4].split('|');
  function e(n) { return (n < a ? '' : e(parseInt(n / a, 10))) + ((n = n % a) > 35 ? String.fromCharCode(n + 29) : n.toString(36)); }
  var d = {};
  while (c--) d[e(c)] = k[c] || e(c);
  return p.replace(/\b\w+\b/g, function (w) { return d[w] || w; }).replace(/\\'/g, "'");
}

function extractMedia(text) {
  var s = String(text).replace(/\\\//g, '/').replace(/&amp;/g, '&');
  var un = unpack(s);
  if (un) s += '\n' + un.replace(/\\\//g, '/');
  var re = /https?:\/\/[^"'\s<>\\)]+?\.(?:m3u8|mp4)(?:\?[^"'\s<>\\)]*)?/gi, m, out = [];
  while ((m = re.exec(s))) if (!BAD_URL.test(m[0])) out.push(m[0]);
  return uniq(out);
}
function isDirect(u) { return /\.(m3u8|mp4)(\?|#|$)/i.test(u); }

// Kumpulkan kandidat (iframe / video / link media) dari sebuah halaman
function collectFromPage(html, pageUrl) {
  var c = [], re = /<(?:iframe|source|video)\b([^>]*)>/gi, m;
  while ((m = re.exec(html))) {
    var src = abs(attr(m[1], 'src') || attr(m[1], 'data-src') || attr(m[1], 'data-lazy-src'), pageUrl);
    if (src && !BAD_URL.test(src)) c.push(src);
  }
  return uniq(c.concat(extractMedia(html)));
}

// URL embed/direct -> [{url, referer}] (hanya direct m3u8/mp4; Nuvio tidak memutar iframe)
function resolveEmbed(url, referer, depth) {
  depth = depth || 0;
  if (isDirect(url)) return Promise.resolve([{ url: url, referer: referer }]);
  if (depth > 1) return Promise.resolve([]);
  return request(url, { headers: { Referer: referer } }).then(function (html) {
    var media = extractMedia(html);
    if (media.length) return media.map(function (u) { return { url: u, referer: url }; });
    var ifr = [], re = /<iframe[^>]+src=["']([^"']+)["']/gi, m;
    while ((m = re.exec(html))) ifr.push(abs(m[1], url));
    return Promise.all(uniq(ifr).slice(0, 3).map(function (u) {
      return resolveEmbed(u, url, depth + 1).catch(function () { return []; });
    })).then(flatten);
  }).catch(function () { return []; });
}
function resolveAll(cands, referer) {
  return Promise.all(uniq(cands).slice(0, 8).map(function (u) {
    return resolveEmbed(u, referer).catch(function () { return []; });
  })).then(flatten);
}

/* ---------- plugin settings ---------- */
function getScraperSettings() {
  try {
    if (typeof globalThis !== 'undefined' && globalThis.SCRAPER_SETTINGS) return globalThis.SCRAPER_SETTINGS;
  } catch (e) {}
  return {};
}
function tmdbSettingsUi() {
  return [
    { type: 'header', label: 'TMDB Configuration' },
    {
      type: 'text', key: 'tmdbApiKey', label: 'TMDB API key / Read Access Token',
      placeholder: 'Paste your TMDB key here',
      description: "Required. Get it from themoviedb.org/settings/api. This is stored in this provider's settings.",
      isPassword: true
    },
    { type: 'info', label: 'Use the v4 API Read Access Token or the v3 API key. Then reopen a title in Nuvio.' }
  ];
}
function onSettings() { return tmdbSettingsUi(); }

/* ---------- TMDB ---------- */
function getTmdbInfo(tmdbId, mediaType, cfg) {
  var settings = getScraperSettings();
  var key = String((cfg && cfg.tmdbApiKey) || settings.tmdbApiKey || TMDB_API_KEY || '').trim();
  if (!key) return Promise.reject(new Error('TMDB key belum diisi. Buka pengaturan provider dan isi TMDB API key.'));
  var kind = mediaType === 'movie' ? 'movie' : 'tv';
  var url = 'https://api.themoviedb.org/3/' + kind + '/' + tmdbId + '?append_to_response=alternative_titles';
  var opts = {};
  if (key.length > 40) opts.headers = { Authorization: 'Bearer ' + key }; else url += '&api_key=' + key;
  return requestJson(url, opts).then(function (d) {
    var t = [d.title, d.name, d.original_title, d.original_name];
    var alt = (d.alternative_titles && (d.alternative_titles.titles || d.alternative_titles.results)) || [];
    for (var i = 0; i < alt.length; i++) t.push(alt[i].title);
    var y = String(d.release_date || d.first_air_date || '').slice(0, 4);
    return { titles: uniq(t).slice(0, 12), year: y, tmdbId: tmdbId };
  });
}

// Coba search satu per satu sampai ada match. searchFn(q) -> Promise<[{title,url}]>
function findMatch(searchFn, titles, min) {
  var tries = titles.slice(0, 4), idx = 0;
  function next() {
    if (idx >= tries.length) return Promise.resolve(null);
    var q = tries[idx++];
    return searchFn(q).then(function (c) { return bestMatch(c, titles, min) || next(); }).catch(function (e) { log('search', e.message); return next(); });
  }
  return next();
}

/* ---------- output ---------- */
function guessQuality(u) {
  var m = /(\d{3,4})p/i.exec(u) || /[_-](\d{3,4})\.(?:mp4|m3u8)/i.exec(u);
  return m ? m[1] + 'p' : 'Auto';
}
function toStream(prov, info, it) {
  var ref = it.referer || prov.referer || '';
  var h = { 'User-Agent': UA };
  if (ref) { h.Referer = ref; h.Origin = originOf(ref); }
  return {
    name: prov.name + (it.label ? ' - ' + it.label : ''),
    title: info.titles[0] + (info.year ? ' (' + info.year + ')' : ''),
    url: it.url,
    quality: it.quality || guessQuality(it.url),
    headers: h,
    provider: prov.id
  };
}

// providers: [{id,name,run(info,mediaType,season,episode)->Promise<[{url,referer,label,quality}]>}]
function makeGetStreams(providers) {
  return function getStreams(tmdbId, mediaType, season, episode, userConfig) {
    var acc = [], seen = {};
    return getTmdbInfo(tmdbId, mediaType, userConfig).then(function (info) {
      log('hub', 'titles: ' + info.titles.slice(0, 3).join(' | '));
      return Promise.all(providers.map(function (p) {
        return p.run(info, mediaType, season, episode).then(function (items) {
          log(p.id, items.length + ' direct link(s)');
          items.forEach(function (it) {
            if (!it.url || seen[it.url]) return;
            seen[it.url] = 1;
            acc.push(toStream(p, info, it));
          });
        }).catch(function (e) { log(p.id, 'error: ' + e.message); });
      })).then(function () { return acc.slice(); });
    }).catch(function (e) {
      log('hub', e.message);
      return [];
    });
  };
}
