// Tes offline untuk alur provider dan kontrak Nuvio.
// Jalankan: node test/mock.test.js (Node.js 18+)
const assert = require('assert');

const routes = [
  [/api\.themoviedb\.org\/3\/tv\/123/, () => JSON.stringify({ name: 'Overflow', original_name: 'Overflow', first_air_date: '2018-01-01', alternative_titles: { results: [{ title: 'Overflow Uncensored' }] } })],
  // HentaiMama
  [/hentaimama\.io\/?\?s=/, () => '<article><a href="https://hentaimama.io/tvshows/overflow/"><img alt="Overflow" src="x.jpg"></a></article>'],
  [/hentaimama\.io\/tvshows\/overflow\/$/, () => '<a href="https://hentaimama.io/episodes/overflow-episode-1/">Ep 1</a><a href="/episodes/overflow-episode-2/">Ep 2</a>'],
  [/hentaimama\.io\/episodes\/overflow-episode-2\/$/, () => '<ul><li id="player-option-1" class="dooplay_player_option" data-type="tv" data-post="55" data-nume="1"></li></ul>'],
  [/hentaimama\.io\/wp-json\/dooplayer\/v2\/55\/tv\/1/, () => JSON.stringify({ embed_url: '<iframe src="https://player.example/embed/abc"></iframe>', type: 'iframe' })],
  [/player\.example\/embed\/abc/, () => '<script>jwplayer().setup({sources:[{file:"https:\\/\\/cdn.example\\/hm-ep2_720.m3u8"}]})</script>'],
  // Hentai.TV
  [/hentai\.tv\/?\?s=/, () => '<a href="https://hentai.tv/hentai/overflow-episode-1/" title="Overflow Episode 1"></a><a href="https://hentai.tv/hentai/overflow-episode-2/" title="Overflow Episode 2"></a><a href="https://hentai.tv/hentai/other-thing-episode-1/" title="Other Thing Episode 1"></a>'],
  [/hentai\.tv\/hentai\/overflow-episode-2\/$/, () => '<iframe data-src="https://nh.example/v/zzz"></iframe>'],
  [/nh\.example\/v\/zzz/, () => '<video><source src="https://cdn.example/htv-ep2_1080.mp4"></video>'],
  // Hanime
  [/search\.htv-services\.com/, () => JSON.stringify({ hits: JSON.stringify([{ name: 'Overflow', slug: 'overflow-1' }]) })],
  [/hanime\.tv\/api\/v8\/video\?id=overflow-1/, () => JSON.stringify({ hentai_video: { slug: 'overflow-1' }, hentai_franchise_hentai_videos: [{ slug: 'overflow-1' }, { slug: 'overflow-2' }], videos_manifest: { servers: [{ name: 'S1', streams: [{ url: 'https://hv.example/ep1.m3u8', height: 720 }] }] } })],
  [/hanime\.tv\/api\/v8\/video\?id=overflow-2/, () => JSON.stringify({ hentai_video: { slug: 'overflow-2' }, hentai_franchise_hentai_videos: [], videos_manifest: { servers: [{ name: 'S1', streams: [{ url: 'https://hv.example/ep2_1080.m3u8', height: 1080 }, { url: '', height: 480 }] }] } })],
];

global.fetch = (url) => {
  const r = routes.find(([re]) => re.test(url));
  if (!r) return Promise.resolve({ status: 404, text: () => Promise.resolve('') });
  const body = r[1]();
  return Promise.resolve({ status: 200, text: () => Promise.resolve(body) });
};

const expected = {
  'hentaimama.js': ['https://cdn.example/hm-ep2_720.m3u8'],
  'hentaitv.js': ['https://cdn.example/htv-ep2_1080.mp4'],
  'hanime.js': ['https://hv.example/ep2_1080.m3u8'],
  'hentai-all.js': ['https://cdn.example/hm-ep2_720.m3u8', 'https://cdn.example/htv-ep2_1080.mp4', 'https://hv.example/ep2_1080.m3u8'],
};

(async () => {
  // Nuvio runs getStreams with four arguments and injects settings globally.
  globalThis.SCRAPER_SETTINGS = { tmdbApiKey: 'abcdefghijklmnopqrstuvwxyz123456' };

  for (const [file, expectUrls] of Object.entries(expected)) {
    const { getStreams, onSettings } = require('../providers/' + file);
    assert.strictEqual(typeof getStreams, 'function', file + ' tidak mengekspor getStreams');
    assert.strictEqual(typeof onSettings, 'function', file + ' tidak mengekspor onSettings');
    const controls = onSettings();
    assert(controls.some((x) => x.key === 'tmdbApiKey' && x.isPassword), file + ' tidak menyediakan input key privat');
    const s = await getStreams('123', 'tv', 1, 2); // signature yang dipakai Nuvio
    const urls = s.map((x) => x.url);
    console.log(file.padEnd(16), urls.join('  '));
    expectUrls.forEach((u) => assert(urls.includes(u), file + ' kurang ' + u));
    s.forEach((x) => { assert(x.name && x.title && x.url && x.quality && x.headers && x.provider); });
  }

  // Engine Nuvio tertentu tidak menyediakan timer global; provider tidak boleh bergantung padanya.
  const oldSetTimeout = global.setTimeout;
  try {
    global.setTimeout = undefined;
    const { getStreams } = require('../providers/hentai-all.js');
    const noTimerResults = await getStreams('123', 'tv', 1, 2);
    assert(noTimerResults.length >= 3, 'provider gagal saat setTimeout tidak tersedia');
  } finally {
    global.setTimeout = oldSetTimeout;
  }

  // Tanpa API key, harus gagal lembut dan mengembalikan array kosong.
  globalThis.SCRAPER_SETTINGS = {};
  const { getStreams } = require('../providers/hentai-all.js');
  assert.deepStrictEqual(await getStreams('123', 'tv', 1, 2), []);

  console.log('SEMUA TES LULUS');
})().catch((e) => { console.error('GAGAL:', e.stack || e.message); process.exit(1); });
